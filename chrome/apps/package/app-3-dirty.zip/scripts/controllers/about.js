'use strict';

/**
 * @ngdoc function
 * @name sopaDeLetrasApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the sopaDeLetrasApp
 */
angular.module('sopaDeLetrasApp')
  .controller('AboutCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
