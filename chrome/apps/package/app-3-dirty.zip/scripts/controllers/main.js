'use strict';

/**
 * @ngdoc function
 * @name sopaDeLetrasApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the sopaDeLetrasApp
 */
angular.module('sopaDeLetrasApp')
  .controller('MainCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
